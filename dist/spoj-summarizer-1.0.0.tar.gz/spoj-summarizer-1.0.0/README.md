# SPOJ SUMMARIZER
[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

> An easy to use tool to track your progress on spoj.

![https://github.com/amulyagaur/SPOJ_SUMMARIZER/blob/master/](Screenshot%20from%202019-02-28%2020-05-25.png)

![https://github.com/amulyagaur/SPOJ_SUMMARIZER/blob/master/](Screenshot%20from%202019-02-28%2020-06-32.png)


## Installation

Clone the repository<br>
Install python3 <br>
Install pandas

```sh
python script.py
```
Amulya Gaur – [@amulyagaur](https://github.com/amulyagaur) – amulyagaur111@gmail.com

## Contributing

1. Fork it (<https://github.com/amulyagaur/SPOJ_SUMMARIZER/fork>)
2. Create your feature branch (`git checkout -b feature/fooBar`)
3. Commit your changes (`git commit -am 'Add some fooBar'`)
4. Push to the branch (`git push origin feature/fooBar`)
5. Create a new Pull Request
